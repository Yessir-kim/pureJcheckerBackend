#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main() {
	Mat color_img = imread("lena.png");
	Mat gray_img = imread("lena.png", 0);

	imshow("lena_color", color_img);
	imshow("lena_gray", gray_img);

	waitKey();
}