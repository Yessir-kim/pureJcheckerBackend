#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main() {
	Mat image_color, image_gray;
	image_color = imread("lena.png");

	cvtColor(image_color, image_gray, CV_BGR2GRAY);

	threshold(image_gray, image_gray, 128, 200, CV_THRESH_BINARY);
	threshold(image_color, image_color, 128, 200, CV_THRESH_BINARY);

	imshow("image_gray", image_gray);
	imshow("image_color", image_color);
	waitKey();
}