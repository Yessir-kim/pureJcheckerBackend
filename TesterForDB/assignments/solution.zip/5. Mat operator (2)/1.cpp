#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main() {
	Mat apple = imread("apple.jpg");
	Mat lena = imread("lena.png");
	Mat dst_sub, dst_absdiff;

	subtract(apple, lena, dst_sub);
	absdiff(apple, lena, dst_absdiff);

	imshow("subtract", dst_sub);
	imshow("absdiff", dst_absdiff);
	waitKey();
}