#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main() {
	Mat image, dst;
	image = imread("apple.jpg");
	cvtColor(image, image, CV_BGR2YCrCb);

	inRange(image, Scalar(0, 157, 0), Scalar(255, 255, 200), dst);

	imshow("inRange", dst);
	waitKey();
}