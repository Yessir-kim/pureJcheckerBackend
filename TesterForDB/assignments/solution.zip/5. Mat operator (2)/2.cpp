#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main() {
	Mat apple = imread("apple.jpg");
	Mat fracture = imread("Fracture_spine.png");
	Mat dst;

	/* conditions for add function:
	1. same size
	2. same number of channels

	If any of the above conditions are not satisfied, error occurs!
	*/
	add(apple, fracture, dst);
	imshow("add", dst);
	waitKey();
}