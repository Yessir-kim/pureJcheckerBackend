#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main() {
	Mat image, image_roi;
	image = imread("sun.jpg");

	Rect rect(Point(50, 50), Point(400, 200));
	image_roi = image(rect);

	image_roi.setTo(Scalar(255, 255, 0));

	imshow("original", image);
	imshow("ROI", image_roi);
	waitKey();
}