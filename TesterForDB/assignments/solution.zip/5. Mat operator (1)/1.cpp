#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main() {
	Mat image, image_hsv;
	Mat hsv_channels[3];

	image = imread("lena.png");

	cvtColor(image, image_hsv, CV_BGR2HSV);
	split(image_hsv, hsv_channels);

	imshow("saturation", hsv_channels[1]);
	waitKey();
}