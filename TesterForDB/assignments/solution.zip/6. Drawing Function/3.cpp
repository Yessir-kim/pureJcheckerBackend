#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main() {
	VideoCapture cap("road.mp4");
	Mat frame;

	double fps = cap.get(CAP_PROP_FPS);
	double delay = 1000 / fps;
	int width = cap.get(CAP_PROP_FRAME_WIDTH);
	int height = cap.get(CAP_PROP_FRAME_HEIGHT);

	while (1) {
		cap >> frame;
		if (frame.empty()) break;

		line(frame, Point(0, 0), Point(width, height), Scalar(0, 0, 255), 4, 8, 0);
		line(frame, Point(width, 0), Point(0, height), Scalar(0, 0, 255), 4, 8, 0);

		imshow("frame", frame);
		waitKey(delay);
	}
}