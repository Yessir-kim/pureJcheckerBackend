#include <iostream>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

int main() {
	Mat image = imread("lena.png");

	Rect rect(Point(204, 200), Point(365, 389));
	rectangle(image, rect, Scalar(0, 255, 0), 4, 8, 0);

	imshow("lena", image);
	waitKey();
}